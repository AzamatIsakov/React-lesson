import { Button, Heading, Card, Counter } from "./components";

function App() {
  return (
    <>
      <Counter />
      <Button value="Hello" />
      <Button value="Bye" bgColor="blue" />
      <Heading text="ABC" type="h2" />
      <Heading text="ABC" type="h4" />
      <Card
        title="Product 1"
        price={239}
        image="https://www.fifecountry.co.uk/images/product_images/large_A976.jpg"
      />
    </>
  );
}

export default App;
