export { default } from "./Counter";
