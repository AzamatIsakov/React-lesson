export { default } from "./Heading";
